#Show/Hide Password EditText  -Changelog

#0.8 (30/06/2016)
- added state saving for `isPassword` (now survives config changes)
- Fix bug where compound drawables on left/top/bottom would be overridden on hide/show

#0.7 (30/06/2016)
- Support for `InputType.TYPE_NUMBER_VARIATION_PASSWORD` input type
- Support for Custom fonts
- **Removed `monospace` attribute (a previous attempt at custom fonts fix)**
- Fixed padding issue (it's not taken into account)
- added new attribute `additionalTouchTargetSize` to give more control of the size of the touch area
which toggles the hide/show password

#0.6 (10/03/2016)
- Added support for Icon tinting 

#0.5 (29/01/2016) 
- Added visual support for pre-Lollipop devices

#0.4 (05/01/2016) 
- monospace attribute

#0.3 (22/12/2015)
- RTL support 
